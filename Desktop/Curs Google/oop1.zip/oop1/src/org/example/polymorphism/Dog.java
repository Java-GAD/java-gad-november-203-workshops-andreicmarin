package org.example.polymorphism;

public class Dog extends Animal{
    @Override
    public void scoateSunet() {
        System.out.println("ham ham");
    }
}