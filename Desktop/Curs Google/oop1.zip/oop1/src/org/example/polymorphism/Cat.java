package org.example.polymorphism;

public class Cat extends Animal{
    public void scoateSunete() {
        System.out.println("miau miau");
    }
}
