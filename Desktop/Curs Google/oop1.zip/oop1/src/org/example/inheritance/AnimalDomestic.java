package org.example.inheritance;

public class AnimalDomestic {
    String nume;

    public AnimalDomestic(String nume) {
        this.nume = nume;
    }

    public void scoateSunete() {
        System.out.println("Sunete random de animal");
    }
}