package org.example.polymorphism;

public class Animal {
    public void scoateSunet() {
        System.out.println("Sunet random de animal!");
    }
}